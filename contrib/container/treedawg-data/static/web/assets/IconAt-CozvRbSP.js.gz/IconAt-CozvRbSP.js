import{N as t}from"./index-BBBzPPmc.js";const a=[["path",{d:"M8 12a4 4 0 1 0 8 0a4 4 0 1 0 -8 0",key:"svg-0"}],["path",{d:"M16 12v1.5a2.5 2.5 0 0 0 5 0v-1.5a9 9 0 1 0 -5.5 8.28",key:"svg-1"}]],e=t("outline","at","At",a);export{e as I};
//# sourceMappingURL=IconAt-CozvRbSP.js.map
